﻿ 

namespace TeamTech.Common
{
    public class FormaData
    {
        public string TimeSpanString { get; set; }
        public string Token { get; set; }
    }
}
