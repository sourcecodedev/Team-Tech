﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TeamTech.Common.DataTable
{
    class ColumnDataTableModel
    {
        public int column { get; set; }
        public string dir { get; set; }
    }
}
