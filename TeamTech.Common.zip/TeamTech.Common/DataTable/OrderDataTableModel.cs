﻿ 

namespace TeamTech.Common.DataTable
{
    class OrderDataTableModel
    {
        public int column { get; set; }
        public string dir { get; set; }
    }
}
